# <p align="center" > تنصيب سورس الشيطان
# <p align="center" > ✘︙[المطور](https://t.me/KKDKKB1)
# <p align="center" > ✘︙[المطور الثاني](https://t.me/F16_ibra)
# <p align="center" > ┉ ✘ ┉ ✘ ┉ ✘ ┉ ✘ ┉
# <p align="center" > ✘ كود التنصيب الاول مع المكاتب ✘
# <p align="center" > `git clone https://github.com/mfmvip/DEMONTeam.git;cd DEMONTeam;chmod +x DEMON.sh;./DEMON.sh install`
# <p align="center" > ┉ ✘ ┉ ✘ ┉ ✘ ┉ ✘ ┉
# <p align="center" > ✘ كود التنصيب السريع من دون مكاتب ✘
# <p align="center" > `git clone https://github.com/mfmvip/DEMONTeam.git;cd DEMONTeam;chmod +x DEMON.sh;./DEMON.sh`
# <p align="center" > ┉ ✘ ┉ ✘ ┉ ✘ ┉ ✘ ┉
# <p align="center" > قم بنسخ احدى اكواد التنصيب
# <p align="center" > والصقه في الترمنال واضغط انتر
# <p align="center" > انتظر الى ان ينتهي التنصيب
# <p align="center" > ✘ بعدها املأ المتطلبات ✘
# <p align="center" > ✘ ايدي المطور • توكن البوت ✘
# <p align="center" > ومبروك عليك تنصيب السورس
# <p align="center" > ┉ ✘ ┉ ✘ ┉ ✘ ┉ ✘ ┉
# <p align="center" > ✘ كود الرن ✘
# <p align="center" > `./DEMONTeam/Run`
# <p align="center" > ┉ ✘ ┉ ✘ ┉ ✘ ┉ ✘ ┉
# <p align="center" > ✘ كود حذف التنصيب ✘
# <p align="center" > `rm -rf DEMONTeam`
# <p align="center" > ┉ ✘ ┉ ✘ ┉ ✘ ┉ ✘ ┉
# <p align="center" > ✘ كود تغير ايدي المطور الاساسي وتوكن البوت ✘
# <p align="center" > `cd DEMONTeam;rm -rf config.lua;./Run`
# <p align="center" > ┉ ✘ ┉ ✘ ┉ ✘ ┉ ✘ ┉

  
